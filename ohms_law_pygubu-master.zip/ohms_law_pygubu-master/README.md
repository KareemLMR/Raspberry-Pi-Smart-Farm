# ohms_law_pygubu
An Ohm's Law calculator with a UI built in Pygubu
